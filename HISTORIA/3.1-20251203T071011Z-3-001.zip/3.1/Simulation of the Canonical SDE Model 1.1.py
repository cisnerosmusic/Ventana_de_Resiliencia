"""
Simulation of the Canonical SDE Model for Resilience Window Verification
Version 3.0 - November 2025

This script simulates the damped harmonic oscillator driven by Ornstein-Uhlenbeck noise.
It computes the steady-state variance of x as a function of R = tau * Omega.
Run this locally to verify if there is a minimum in variance (resilience valley).

Usage:
  python sde_simulation.py

Requirements:
  numpy
  matplotlib

Notes:
  - For coupled damping (gamma = 1 / tau), as in the paper's canonical model.
  - For fixed damping (gamma fixed).
  - Long T and small dt for accuracy, but adjustable for speed.
  - Burn-in to discard transient.
  - Average over multiple runs for better statistics (optional).
"""

import numpy as np
import matplotlib.pyplot as plt

def simulate_sde(R, Omega=1.0, Gamma=1.0, coupled_damping=True, T=20000, dt=0.01, burn_in=5000, num_runs=1):
    tau = R / Omega
    if coupled_damping:
        gamma = 1 / tau
    else:
        gamma = 0.5  # fixed underdamped example; adjust as needed
    
    var_sum = 0.0
    for _ in range(num_runs):
        N = int(T / dt)
        burn_steps = int(burn_in / dt)
        
        x = np.zeros(N)
        y = np.zeros(N)  # velocity
        zeta = np.zeros(N)
        
        sqrt_dt = np.sqrt(dt)
        noise_scale = np.sqrt(2 * Gamma / tau)
        
        for i in range(1, N):
            dW = np.random.normal(0.0, sqrt_dt)
            
            zeta[i] = zeta[i-1] + (-zeta[i-1] / tau * dt + noise_scale * dW)
            
            y[i] = y[i-1] + (-gamma * y[i-1] - Omega**2 * x[i-1] + zeta[i-1]) * dt
            
            x[i] = x[i-1] + y[i-1] * dt  # Euler step for position using previous velocity
        
        steady_x = x[burn_steps:]
        var_sum += np.mean(steady_x**2)  # time average of x^2 (assuming mean x ~0)
    
    var_x = var_sum / num_runs
    return var_x

if __name__ == "__main__":
    Rs = np.linspace(0.1, 5.0, 20)
    
    vars_coupled = [simulate_sde(R) for R in Rs]
    
    vars_fixed = [simulate_sde(R, coupled_damping=False) for R in Rs]
    
    plt.figure(figsize=(10, 6))
    plt.plot(Rs, vars_coupled, label='Coupled damping (gamma = 1/tau)', marker='o')
    plt.plot(Rs, vars_fixed, label='Fixed damping (gamma = 0.5)', marker='x')
    plt.xlabel('R = τ Ω')
    plt.ylabel('Steady-state variance <x²>')
    plt.title('Variance vs Resilience Parameter R')
    plt.legend()
    plt.grid(True)
    plt.savefig('resilience_variance_plot.png')
    plt.show()
    
    # Find min for coupled
    min_idx = np.argmin(vars_coupled)
    print(f"Coupled: Minimum variance {vars_coupled[min_idx]:.4f} at R = {Rs[min_idx]:.2f}")
    
    # Find min for fixed
    min_idx_f = np.argmin(vars_fixed)
    print(f"Fixed: Minimum variance {vars_fixed[min_idx_f]:.4f} at R = {Rs[min_idx_f]:.2f}")