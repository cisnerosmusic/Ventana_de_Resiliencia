import numpy as np
import matplotlib.pyplot as plt

def simulate_sde(R, Omega=1.0, Gamma=1.0,
                 coupled_damping=True,
                 T=20000.0, dt=0.01,
                 burn_in=5000.0,
                 num_runs=1, seed=None):
    tau = R / Omega
    if coupled_damping:
        gamma = 1.0 / tau
    else:
        gamma = 0.5  # ejemplo de amortiguamiento fijo
    
    if seed is not None:
        np.random.seed(seed)
    
    var_sum = 0.0
    for run in range(num_runs):
        N = int(T / dt)
        burn_steps = int(burn_in / dt)
        
        x = np.zeros(N)
        y = np.zeros(N)      # velocidad
        zeta = np.zeros(N)   # ruido OU
        
        sqrt_dt = np.sqrt(dt)
        noise_scale = np.sqrt(2.0 * Gamma / tau)
        
        for i in range(1, N):
            dW = np.random.normal(0.0, sqrt_dt)
            
            # OU noise (Euler–Maruyama)
            zeta[i] = zeta[i-1] + (-zeta[i-1] / tau * dt + noise_scale * dW)
            
            # Oscilador amortiguado forzado por zeta
            y[i] = y[i-1] + (-gamma * y[i-1] - Omega**2 * x[i-1] + zeta[i]) * dt
            x[i] = x[i-1] + y[i] * dt
        
        steady_x = x[burn_steps:]
        var_sum += np.mean(steady_x**2)
    
    var_x = var_sum / num_runs
    return var_x

if __name__ == "__main__":
    Rs = np.linspace(0.1, 5.0, 20)
    
    vars_coupled = [simulate_sde(R, coupled_damping=True,  num_runs=3) for R in Rs]
    vars_fixed   = [simulate_sde(R, coupled_damping=False, num_runs=3) for R in Rs]
    
    plt.figure(figsize=(10, 6))
    plt.plot(Rs, vars_coupled, label='Coupled damping (gamma = 1/τ)', marker='o')
    plt.plot(Rs, vars_fixed,   label='Fixed damping (gamma = 0.5)',  marker='x')
    plt.xlabel('R = τ Ω')
    plt.ylabel('Steady-state variance ⟨x²⟩')
    plt.title('Variance vs Resilience Parameter R (SDE simulation)')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig('resilience_variance_plot.png', dpi=200)
    plt.show()
    
    min_idx_c = np.argmin(vars_coupled)
    print(f"Coupled: min ⟨x²⟩ = {vars_coupled[min_idx_c]:.4e} at R = {Rs[min_idx_c]:.2f}")
    
    min_idx_f = np.argmin(vars_fixed)
    print(f"Fixed:   min ⟨x²⟩ = {vars_fixed[min_idx_f]:.4e} at R = {Rs[min_idx_f]:.2f}")
